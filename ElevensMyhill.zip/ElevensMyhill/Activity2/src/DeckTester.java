/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		String[] suits = {"Diamonds", "Hearts", "Spades"};
		String[] ranks = {"Queen", "Jack", "King"};
		int[] vals = {333, 256, 333};
		Deck use = new Deck(ranks, suits, vals);

		String[] suits2 = {"Diamonds", "Spades"};
		String[] ranks2 = {"Jack", "King"};
		int[] vals2 = {33, 32};
		Deck use2 = new Deck(ranks2, suits2, vals2);

		String[] suits3 = {"Hearts"};
		String[] ranks3 = {"Queen"};
		int[] vals3 = {3333};
		Deck use3 = new Deck(ranks3, suits3, vals3);

		while(!use.isEmpty()){
			System.out.println(use.deal());
		}

		while(!use2.isEmpty()){
			System.out.println(use2.deal());
		}

		while(!use3.isEmpty()){
			System.out.println(use3.deal());
		}
		}
	}

